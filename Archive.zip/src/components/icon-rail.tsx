"use client";

import { useMusic } from "@/context/music-context";
import { initials } from "@/lib/utils";
import {
  Disc3,
  FolderArchive,
  Heart,
  Home,
  ListMusic,
  PanelLeftClose,
  PanelLeftOpen,
  Search,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";

export function IconRail() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentView = searchParams.get("view");
  const { songs } = useMusic();

  // Collapsed state is remembered across sessions
  const [collapsed, setCollapsedRaw] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    try {
      return localStorage.getItem("orbit_sidebar_collapsed") === "true";
    } catch {
      return false;
    }
  });
  function toggleCollapsed() {
    setCollapsedRaw((prev) => {
      const next = !prev;
      try {
        localStorage.setItem("orbit_sidebar_collapsed", String(next));
      } catch { }
      return next;
    });
  }

  const menuItems = [
    { href: "/home", label: "Home", icon: Home, isActive: pathname === "/home" || pathname === "/" },
    { href: "/music?view=albums", label: "Albums", icon: Disc3, isActive: pathname === "/music" && currentView === "albums" },
    { href: "/downloaded", label: "Local Files", icon: FolderArchive, isActive: pathname === "/downloaded" },
    { href: "/favourites", label: "Favorites", icon: Heart, isActive: pathname === "/favourites" },
    { href: "/folders", label: "Playlists", icon: ListMusic, isActive: pathname === "/folders" || pathname.startsWith("/folders/") },
  ];

  // Replaces the "Friends" list with artists from the library
  const artists = useMemo(() => {
    const map = new Map<string, { name: string; image?: string | null; sub: string }>();
    for (const s of songs) {
      const name = s.artist?.name;
      if (!name || map.has(name)) continue;
      map.set(name, { name, image: s.artist?.image_url, sub: s.title });
      if (map.size >= 6) break;
    }
    return Array.from(map.values());
  }, [songs]);

  return (
    <aside
      className={`hidden h-full shrink-0 flex-col bg-[#1a1a1c] py-7 text-zinc-300 transition-[width] duration-200 md:flex ${collapsed ? "w-[72px] items-center px-3" : "w-56 px-5 lg:w-60"
        }`}
    >
      <div className={`flex items-center ${collapsed ? "justify-center" : "justify-between px-1"}`}>
        {!collapsed && <h2 className="text-[22px] font-bold tracking-tight text-white">Menu</h2>}
        <button
          type="button"
          onClick={toggleCollapsed}
          aria-label={collapsed ? "Show sidebar" : "Hide sidebar"}
          title={collapsed ? "Show sidebar" : "Hide sidebar"}
          className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition hover:bg-white/10 hover:text-white"
        >
          {collapsed ? <PanelLeftOpen className="h-[18px] w-[18px]" /> : <PanelLeftClose className="h-[18px] w-[18px]" />}
        </button>
      </div>

      <nav className={`mt-4 space-y-0.5 ${collapsed ? "w-full" : ""}`}>
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.label}
              href={item.href}
              prefetch
              onClick={(e) => {
                if (item.isActive) e.preventDefault();
              }}
              className={`group flex items-center gap-3 rounded-lg px-1 py-2.5 text-[13px] font-semibold transition ${item.isActive ? "text-white" : "text-zinc-400 hover:text-white"
                }`}
            >
              <Icon
                className={`h-[18px] w-[18px] ${item.isActive ? "text-blue-500" : "text-zinc-600 group-hover:text-zinc-300"
                  }`}
              />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {!collapsed && (
        <h2 className="mt-9 px-1 text-[22px] font-bold tracking-tight text-white">Artists</h2>
      )}
      <div className={`no-scrollbar min-h-0 flex-1 space-y-4 overflow-y-auto ${collapsed ? "mt-6" : "mt-4"}`}>
        {artists.map((a) => (
          <Link
            key={a.name}
            href={`/artists/${encodeURIComponent(a.name)}`}
            title={collapsed ? a.name : undefined}
            className={`group flex items-center ${collapsed ? "justify-center" : "gap-3 px-1"}`}
          >
            {a.image ? (
              <img src={a.image} alt={a.name} className="h-9 w-9 shrink-0 rounded-full object-cover ring-2 ring-white/10" />
            ) : (
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-zinc-800 text-[11px] font-bold text-zinc-300">
                {initials(a.name)}
              </div>
            )}
            {!collapsed && (
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold text-zinc-200 group-hover:text-white">{a.name}</p>
                <p className="truncate text-[10px] text-zinc-500">{a.sub}</p>
              </div>
            )}
          </Link>
        ))}
      </div>

      <Link
        href="/music?view=artists"
        title="Find more artists"
        className={`mt-4 flex items-center rounded-full bg-[#2a2a2d] text-xs text-zinc-400 transition hover:text-white ${collapsed ? "h-10 w-10 justify-center" : "justify-between px-4 py-2.5"
          }`}
      >
        {!collapsed && <span>Find more artists</span>}
        <Search className="h-4 w-4" />
      </Link>
    </aside>
  );
}

export function OrbitMark({ className = "h-6 w-6" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden>
      <circle cx="16" cy="16" r="4" fill="#3b82f6" />
      <circle cx="16" cy="16" r="8" fill="none" stroke="#3b82f6" strokeWidth="1.4" opacity="0.6" />
      <ellipse
        cx="16"
        cy="16"
        rx="13"
        ry="7"
        fill="none"
        stroke="#ffffff"
        strokeWidth="1.2"
        opacity="0.8"
        transform="rotate(-24 16 16)"
      />
    </svg>
  );
}